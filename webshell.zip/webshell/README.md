# Bachelor Thesis
## Analyzing a web shell upload attack based on container virtualization

### Docker Test Environment based on a messenger web application case.

### Includes following container
- Web Server: Running a PHP Apache Server serving a static html file
- Database: MySQL Database
- Kali Linux: Having pentration testing tools
- w3af: Security Scanner